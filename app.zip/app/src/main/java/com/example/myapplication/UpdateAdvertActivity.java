package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class UpdateAdvertActivity extends AppCompatActivity {

    EditText name, phone, description, date, location;
    Button deleteAdvert;
    String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_advert);

        name = findViewById(R.id.name);
        description = findViewById(R.id.description);
        phone = findViewById(R.id.phone);
        date = findViewById(R.id.date);
        location = findViewById(R.id.location);
        deleteAdvert = findViewById(R.id.deleteAdvert);

        Intent i = getIntent();
        name.setText(i.getStringExtra("name"));
        phone.setText(i.getStringExtra("phone"));
        description.setText(i.getStringExtra("description"));
        date.setText(i.getStringExtra("date"));
        location.setText(i.getStringExtra("location"));
        id = i.getStringExtra("id");

        deleteAdvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDialog();
            }
        });

    }
    void confirmDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + name.getText().toString() + " ?");
        builder.setMessage("Confirm Delete ? " + name.getText().toString() + " ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                DatabaseClass db = new DatabaseClass(UpdateAdvertActivity.this);
                db.deleteAdvertByRow(id);
                finish();

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.create().show();
    }
}
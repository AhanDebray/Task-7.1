package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {

    Context context;
    Activity activity;
    List<Model> advertList;

    public Adapter(Context context, Activity activity, List<Model> advertList) {
        this.context = context;
        this.activity = activity;
        this.advertList = advertList;
    }

    @NonNull
    @Override
    public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_layout,parent,false);
        return new MyViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull Adapter.MyViewHolder holder, int position) {
        holder.name.setText(advertList.get(position).getName());
        holder.phone.setText(advertList.get(position).getPhone());
        holder.description.setText(advertList.get(position).getDescription());
        holder.date.setText(advertList.get(position).getDate());
        holder.location.setText(advertList.get(position).getLocation());
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdateAdvertActivity.class);

                intent.putExtra("name", advertList.get(position).getName());
                intent.putExtra("phone", advertList.get(position).getPhone());
                intent.putExtra("description", advertList.get(position).getDescription());
                intent.putExtra("date", advertList.get(position).getDate());
                intent.putExtra("location", advertList.get(position).getLocation());
                intent.putExtra("id", advertList.get(position).getId());
                activity.startActivityForResult(intent,1);
            }
        });
    }
    @Override
    public int getItemCount() {
        return advertList.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name, phone, description, date, location;
        RelativeLayout layout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            phone = itemView.findViewById(R.id.phone);
            description = itemView.findViewById(R.id.description);
            date = itemView.findViewById(R.id.date);
            location = itemView.findViewById(R.id.location);
            layout = itemView.findViewById(R.id.advert_layout);
        }
    }
}
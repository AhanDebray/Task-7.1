package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateNotesActivity extends AppCompatActivity {

    EditText title, phone, description, date, location;
    Button deleteNote;
    String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_notes);

        title = findViewById(R.id.title);
        description = findViewById(R.id.description);
        phone = findViewById(R.id.phone);
        date = findViewById(R.id.date);
        location = findViewById(R.id.location);
        deleteNote = findViewById(R.id.deleteNote);

        Intent i = getIntent();
        title.setText(i.getStringExtra("title"));
        phone.setText(i.getStringExtra("phone"));
        description.setText(i.getStringExtra("description"));
        date.setText(i.getStringExtra("date"));
        location.setText(i.getStringExtra("location"));
        id = i.getStringExtra("id");

        deleteNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDialog();
            }
        });

    }
    void confirmDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + title.getText().toString() + " ?");
        builder.setMessage("Are you sure you want to delete " + title.getText().toString() + " ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                DatabaseClass db = new DatabaseClass(UpdateNotesActivity.this);
                db.deleteNoteByRow(id);
                finish();

            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }
}
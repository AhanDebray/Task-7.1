package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class AddAdvertActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    String type;
    TextView textView;
    EditText name, description, phone, date, location;
    Button saveAdvert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_advert);
        textView = findViewById(R.id.textView);
        name = findViewById(R.id.name);
        description = findViewById(R.id.description);
        phone = findViewById(R.id.phone);
        date = findViewById(R.id.date);
        location = findViewById(R.id.location);
        saveAdvert = findViewById(R.id.saveAdvert);
        radioGroup = (RadioGroup)findViewById(R.id.type);
        radioGroup.clearCheck();

        radioGroup.setOnCheckedChangeListener(
                new RadioGroup
                        .OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group,
                                                 int checkedId)
                    {
                        RadioButton
                                radioButton
                                = (RadioButton)group
                                .findViewById(checkedId);
                        type = radioButton.getText().toString();
                    }
                });

        saveAdvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!TextUtils.isEmpty(name.getText().toString()) && !TextUtils.isEmpty(description.getText().toString()) && !TextUtils.isEmpty(phone.getText().toString()) && !TextUtils.isEmpty(date.getText().toString()) && !TextUtils.isEmpty(location.getText().toString()))
                {
                    DatabaseClass db = new DatabaseClass(AddAdvertActivity.this);
                    db.addAdvert((type+ " " + name.getText().toString()),phone.getText().toString(),description.getText().toString(),date.getText().toString(),location.getText().toString());
                    Intent intent = new Intent(AddAdvertActivity.this, MainActivity2.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(AddAdvertActivity.this, "Both Fields are Empty", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
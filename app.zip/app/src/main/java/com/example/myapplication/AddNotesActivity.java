package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class AddNotesActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    String type;
    TextView textView;
    EditText title, description, phone, date, location;
    Button saveNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_notes);

        textView = findViewById(R.id.textView);
        title = findViewById(R.id.title);
        description = findViewById(R.id.description);
        phone = findViewById(R.id.phone);
        date = findViewById(R.id.date);
        location = findViewById(R.id.location);
        saveNote = findViewById(R.id.saveNote);
        radioGroup = (RadioGroup)findViewById(R.id.type);
        radioGroup.clearCheck();

        radioGroup.setOnCheckedChangeListener(
                new RadioGroup
                        .OnCheckedChangeListener() {
                    @Override

                    // The flow will come here when
                    // any of the radio buttons in the radioGroup
                    // has been clicked

                    // Check which radio button has been clicked
                    public void onCheckedChanged(RadioGroup group,
                                                 int checkedId)
                    {

                        // Get the selected Radio Button
                        RadioButton
                                radioButton
                                = (RadioButton)group
                                .findViewById(checkedId);
                        type = radioButton.getText().toString();
                    }
                });

        saveNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!TextUtils.isEmpty(title.getText().toString()) && !TextUtils.isEmpty(description.getText().toString()) && !TextUtils.isEmpty(phone.getText().toString()) && !TextUtils.isEmpty(date.getText().toString()) && !TextUtils.isEmpty(location.getText().toString()))
                {
                    DatabaseClass db = new DatabaseClass(AddNotesActivity.this);
                    db.addNotes((type+ " " + title.getText().toString()),phone.getText().toString(),description.getText().toString(),date.getText().toString(),location.getText().toString());


                    Intent intent = new Intent(AddNotesActivity.this, MainActivity2.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }

                else
                {
                    Toast.makeText(AddNotesActivity.this, "Both Fields are Empty", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}